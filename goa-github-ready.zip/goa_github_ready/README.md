# Tslottery (Node.js + Express + EJS + MySQL)

This repository contains the application source. It does not include `node_modules`, local secrets (`.env`), or the large SQL dump.

## Requirements

- Node.js 18 or 20 (use the same major version consistently)
- npm
- MySQL 8.x (or a compatible MySQL server)

## 1. Install dependencies

```bash
npm install
```

## 2. Configure environment

Copy `.env.example` to `.env` and fill in the database and provider credentials:

```bash
cp .env.example .env
```

On Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Never commit `.env`. The `.gitignore` excludes it.

## 3. Create the database

Create a MySQL database and user matching `DB_NAME`, `DB_USER`, and `DB_PASSWORD` in `.env`, then import your SQL backup using MySQL Workbench or:

```bash
mysql -u root -p goagame < path/to/your-backup.sql
```

The original SQL dump is intentionally kept outside this GitHub source package because it is a large database backup and may contain private/user data. Review it before sharing it anywhere.

## 4. Start the application

```bash
npm start
```

Development mode:

```bash
npm run dev
```

Open `http://localhost:3000` on the same computer (or the port set in `.env`).

## 5. Open on a phone on the same Wi-Fi

1. Connect the phone and computer to the same Wi-Fi network.
2. Find the computer's local IPv4 address (`ipconfig` on Windows; `ip addr` on Linux).
3. Keep `HOST=0.0.0.0` in `.env`.
4. Allow Node.js through the computer firewall for your private network.
5. On the phone, open `http://COMPUTER-LAN-IP:3000`, replacing the example with the computer's actual IPv4 address.

This is local-network access only. It does not publish the site to the public internet. Do not expose this application publicly until authentication, payment callbacks, admin routes, database access, and production security have been reviewed.

## GitHub upload

Create an empty GitHub repository, then from this project folder run:

```bash
git init
git add .
git status
git commit -m "Initial project upload"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Before committing, check `git status` and make sure `.env`, `node_modules`, and SQL backups are not staged.

## Important notes

- This is an older Babel-based application. A successful GitHub upload does not guarantee that every runtime dependency or external service works on a fresh machine.
- The app expects a MySQL database and provider credentials. GitHub Pages and Google AI Studio are not substitutes for this backend/database environment.
- Test with a disposable local database first. Do not use real customer funds or production credentials during setup.
